MathJax = {
  tex: {
    processEnvironments: false
  }
}
